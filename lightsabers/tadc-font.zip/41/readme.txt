  ________      ___         ______     ____
 |__    __|    / _ \       |  __  \   /  __|
    |  |      / / \ \      | |  \  | |  /
    |  |     / _____ \     | |   | | | |
    |  |    / ______  \    | |   | | | |
    |  |   / /       \ \   | |__/  | |  \__
    |__|  /_/         \_\  |______/   \____|



  This is my Amazing Digital Circus font. 
By far the goofiest font I've made so far,
this font had myself and my older brother 
laughing 'till we cried. 

All sounds are pulled from The Amazing 
Digital Circus TV show, and therefor are
copyright of Glitch Productions and Goose-
worx. 